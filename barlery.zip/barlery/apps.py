from django.apps import AppConfig


class BarleryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'barlery'
