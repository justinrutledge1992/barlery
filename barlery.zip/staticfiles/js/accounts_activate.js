/**
 * Accounts Activation JavaScript
 * Handles user account activation
 */

document.addEventListener('DOMContentLoaded', function() {
    console.log('Accounts Activation loaded');
    
    // Get CSRF token from cookies
    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
    
    const csrftoken = getCookie('csrftoken');
    
    // Handle activate buttons
    const activateButtons = document.querySelectorAll('[data-action="activate"]');
    
    activateButtons.forEach(button => {
        button.addEventListener('click', function() {
            const userId = this.closest('.pending-user-card').dataset.userId;
            const userFirstName = this.dataset.userFirstName;
            const userLastName = this.dataset.userLastName;
            const userEmail = this.dataset.userEmail;
            
            // Show confirmation dialog
            const confirmMessage = `Activate account for ${userFirstName} ${userLastName} (${userEmail})?`;
            
            if (confirm(confirmMessage)) {
                // User confirmed - send activate request
                activateUser(userId, userFirstName, userLastName, userEmail);
            }
        });
    });
    
    function activateUser(userId, userFirstName, userLastName, userEmail) {
        // Disable the button to prevent double-clicks
        const button = document.querySelector(`[data-user-id="${userId}"] [data-action="activate"]`);
        if (button) {
            button.disabled = true;
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Activating...';
        }
        
        // Send POST request to activate
        fetch(`/accounts/activate/${userId}/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrftoken,
            },
            body: JSON.stringify({
                user_id: userId
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Show success message via alert banner (page will reload and show message)
                window.location.href = '/accounts/activate?activated=true&name=' + encodeURIComponent(`${userFirstName} ${userLastName}`);
            } else {
                // Show error message
                alert(`Error: ${data.error || 'Failed to activate user'}`);
                // Re-enable button
                if (button) {
                    button.disabled = false;
                    button.innerHTML = '<i class="fas fa-user-check"></i> Activate Account';
                }
            }
        })
        .catch(error => {
            console.error('Error activating user:', error);
            alert('An error occurred while activating the user. Please try again.');
            // Re-enable button
            if (button) {
                button.disabled = false;
                button.innerHTML = '<i class="fas fa-user-check"></i> Activate Account';
            }
        });
    }
});
